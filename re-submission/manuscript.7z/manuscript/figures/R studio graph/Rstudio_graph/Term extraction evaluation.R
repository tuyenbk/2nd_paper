data <- read.csv("term extraction evaluation.csv")
